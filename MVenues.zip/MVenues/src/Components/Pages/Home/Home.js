
import "./Home.css";
function Home() {
  return (
    <div className="Hcontainer">
      <h1 id="Hpara">The Best Live Music Venues In The World</h1>
    </div>
  );
}

export default Home;
